# Design previews

Desktop (1440px) and mobile (390px) captures of the three-page design. Captured before the final submission-error fix and a small mobile text-spacing correction; both corrections are included in the source. These are design previews, not evidence of live email or booking integration.
