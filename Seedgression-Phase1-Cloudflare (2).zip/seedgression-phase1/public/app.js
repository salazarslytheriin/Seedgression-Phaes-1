import settings from './site-config.js';
import { validateInput, validEmail } from './validation.js';

const q = (selector) => document.querySelector(selector);
document.querySelectorAll('[data-year]').forEach(el => { el.textContent = String(new Date().getFullYear()); });

const menu = q('.menu-toggle'), nav = q('#main-nav');
const narrow = matchMedia('(max-width: 700px)');
function setMenu(open) {
  menu.setAttribute('aria-expanded', String(open));
  menu.lastElementChild.textContent = open ? '−' : '+';
  nav.dataset.collapsed = String(narrow.matches && !open);
}
menu.hidden = !narrow.matches;
setMenu(false);
menu.addEventListener('click', () => setMenu(menu.getAttribute('aria-expanded') !== 'true'));
narrow.addEventListener('change', () => { menu.hidden = !narrow.matches; setMenu(false); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && menu.getAttribute('aria-expanded') === 'true') { setMenu(false); menu.focus(); }
});
nav.addEventListener('click', event => { if (event.target.closest('a')) setMenu(false); });

if (validEmail(settings.contactEmail)) {
  document.querySelectorAll('[data-contact-email-wrap]').forEach(el => { el.hidden = false; });
  document.querySelectorAll('[data-contact-email]').forEach(el => {
    el.href = `mailto:${settings.contactEmail}`;
    el.textContent = settings.contactEmail;
  });
}
const privacyEmail = settings.privacyContact || settings.contactEmail;
if (validEmail(privacyEmail) && q('[data-privacy-contact]')) {
  const link = document.createElement('a');
  link.href = `mailto:${privacyEmail}`; link.textContent = privacyEmail;
  q('[data-privacy-contact]').replaceChildren('To ask about information you have shared, email ', link, '.');
}
function expandPrivacy() {
  if (location.hash === '#privacy') q('#privacy details')?.setAttribute('open', '');
}
window.addEventListener('hashchange', expandPrivacy);
expandPrivacy();

if (q('#booking-link') && settings.calendlyUrl) {
  try {
    const url = new URL(settings.calendlyUrl);
    if (url.protocol === 'https:' && ['calendly.com', 'www.calendly.com'].includes(url.hostname) && !url.username && !url.password && url.pathname !== '/') {
      q('#booking-link').href = url.href;
      q('#booking-link').hidden = false;
      q('#booking-unavailable').hidden = true;
      q('#booking-note').hidden = false;
    }
  } catch { /* Leave booking unavailable until a valid URL is configured. */ }
}

const form = q('#contact-form');
if (form) {
  form.addEventListener('submit', event => event.preventDefault());
  setupForm();
}

async function setupForm() {
  const button = form.querySelector('button[type=submit]');
  const status = q('#form-status');
  let ready = false, busy = false, token = '', widgetId = null, preview = false;
  let submissionId = '', previousPayload = '', submissionFailure = '';
  const setStatus = (message, error = false) => { status.textContent = message; status.classList.toggle('error', error); };
  const refreshButton = () => { button.disabled = busy || !ready || (!preview && !token); };
  const countMessage = () => { q('#message-count').textContent = `${q('#message').value.length.toLocaleString('en-US')} / 5,000`; };
  q('#message').addEventListener('input', countMessage);
  countMessage();
  function showErrors(errors) {
    for (const key of ['name', 'company', 'email', 'message']) {
      const el = q(`#${key}`), err = q(`#${key}-error`);
      err.textContent = errors[key] || '';
      if (errors[key]) { el.setAttribute('aria-invalid', 'true'); el.setAttribute('aria-describedby', `${key}-error`); }
      else { el.removeAttribute('aria-invalid'); el.removeAttribute('aria-describedby'); }
    }
  }
  form.addEventListener('input', event => {
    if (event.target.matches('input, textarea')) {
      const err = q(`#${event.target.id}-error`);
      if (err) { err.textContent = ''; event.target.removeAttribute('aria-invalid'); event.target.removeAttribute('aria-describedby'); }
    }
  });
  try {
    const response = await fetch('/api/config', { signal: AbortSignal.timeout(8000), cache: 'no-store' });
    if (!response.ok) throw new Error('unavailable');
    const config = await response.json();
    ready = config.formReady === true;
    preview = config.preview === true;
    if (!ready) {
      setStatus('Online enquiries are not available yet.' + (settings.contactEmail ? ' Please use the email link to contact us.' : ' Please check back soon.'));
      return;
    }
    if (preview) { setStatus('Local preview: submissions are tested without sending emails.'); refreshButton(); }
    else {
      setStatus('Complete the security check to send your enquiry.');
      const script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.async = true;
      const timer = setTimeout(() => setStatus('The security check is taking longer than expected. Refresh this page or use our email link.', true), 15000);
      script.onload = () => {
        clearTimeout(timer);
        widgetId = window.turnstile.render('#turnstile-widget', {
          sitekey: settings.turnstileSiteKey, theme: 'dark', size: 'flexible', action: 'contact',
          callback: value => { token = value; setStatus(submissionFailure, !!submissionFailure); refreshButton(); },
          'expired-callback': () => { token = ''; setStatus('Please complete the security check again.'); refreshButton(); },
          'error-callback': () => { token = ''; setStatus('The security check could not finish. Refresh this page or use our email link.', true); refreshButton(); }
        });
      };
      script.onerror = () => { clearTimeout(timer); setStatus('The security check could not load. Refresh this page or use our email link.', true); };
      document.head.append(script);
    }
  } catch { setStatus('The form is temporarily unavailable. Please refresh the page and try again.', true); }

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (busy || !ready) return;
    const raw = Object.fromEntries(new FormData(form));
    const result = validateInput(raw);
    showErrors(result.errors);
    if (!result.valid) { q(`#${Object.keys(result.errors)[0]}`).focus(); return; }
    if (!preview && !token) { setStatus('Please complete the security check.', true); return; }
    const encoded = JSON.stringify(result.fields);
    if (encoded !== previousPayload || !submissionId) { submissionId = crypto.randomUUID(); previousPayload = encoded; }
    busy = true; submissionFailure = ''; refreshButton(); setStatus('Sending your enquiry…');
    try {
      const response = await fetch('/api/contact', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ ...result.fields, website: raw.website || '', submissionId, turnstileToken: token }),
        signal: AbortSignal.timeout(45000)
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || data.ok !== true) {
        if (data.errors) { showErrors(data.errors); q(`#${Object.keys(data.errors)[0]}`)?.focus(); }
        throw new Error(data.message || 'We could not submit your enquiry. Your message is still here; please try again.');
      }
      form.hidden = true;
      q('#form-success').hidden = false;
      q('#success-message').textContent = data.preview
        ? 'Preview successful. No email was sent and no automation was triggered.'
        : data.receiptAccepted
          ? 'Your enquiry has been submitted to our team. An acknowledgement is on its way to your inbox.'
          : 'Your enquiry has been submitted to our team. We could not send the acknowledgement email, but you do not need to submit again.';
      q('#success-reference').textContent = data.reference ? `Enquiry reference: ${data.reference}` : '';
      form.reset(); q('#form-success').focus();
    } catch (error) {
      const message = error.name === 'TimeoutError' || error.name === 'TypeError'
        ? 'We could not confirm the submission. Your message is still here; please try again.' : error.message;
      submissionFailure = message; setStatus(message, true);
      token = '';
      if (widgetId !== null) window.turnstile.reset(widgetId);
    } finally { busy = false; refreshButton(); }
  });
}
