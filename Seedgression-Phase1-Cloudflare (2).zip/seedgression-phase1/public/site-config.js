// PUBLIC settings. These values are visible to every visitor.
// Leave a feature blank until its real details are available, then redeploy.
export default Object.freeze({
  siteUrl: "", // Final HTTPS origin, e.g. https://seedgression.com (no trailing slash).
  contactEmail: "", // An existing inbox that the team actually checks.
  calendlyUrl: "", // Your event URL, e.g. https://calendly.com/your-team/discovery.
  turnstileSiteKey: "", // Public Cloudflare Turnstile site key (NOT the secret key).
  privacyContact: "" // Optional privacy contact inbox; defaults to contactEmail.
});
