export const LIMITS = Object.freeze({ name: 100, company: 150, email: 254, message: 5000 });
export const validEmail = value => typeof value === 'string' && value.length <= 254 && /^[^\s@<>"(),;:\\]+@[^\s@<>"(),;:\\]+\.[^\s@<>"(),;:\\]+$/.test(value);

export function validateInput(input) {
  const fields = {}, errors = {};
  for (const key of Object.keys(LIMITS)) {
    if (typeof input?.[key] !== 'string') {
      if (key === 'company' && input?.[key] == null) fields[key] = '';
      else { fields[key] = ''; errors[key] = 'Please enter a valid value.'; }
    } else fields[key] = input[key].trim().replace(/\r\n?/g, '\n');
  }
  if (!fields.name || fields.name.length > LIMITS.name || /[\x00-\x1f\x7f]/.test(fields.name)) errors.name = 'Enter your name (up to 100 characters).';
  if (!validEmail(fields.email)) errors.email = 'Enter a valid email address.';
  if (fields.company.length > LIMITS.company || /[\x00-\x1f\x7f]/.test(fields.company)) errors.company = 'Enter a company name up to 150 characters.';
  if (fields.message.length < 10 || fields.message.length > LIMITS.message || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(fields.message)) errors.message = 'Write between 10 and 5,000 characters.';
  return { fields, errors, valid: Object.keys(errors).length === 0 };
}
