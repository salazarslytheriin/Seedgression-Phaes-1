// Local preview only: runs the Worker with fake external services. Never deployed.
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createWorker } from '../src/worker.js';
import settings from '../public/site-config.js';

const root = resolve(import.meta.dirname, '../public');
const port = Number(process.env.PREVIEW_PORT || 8788);
const origin = `http://127.0.0.1:${port}`;
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.png': 'image/png', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.txt': 'text/plain' };
const worker = createWorker({
  settings: { ...settings, turnstileSiteKey: 'LOCAL_PREVIEW_ONLY' },
  fetcher: async url => String(url).includes('/siteverify')
    ? Response.json({ success: true, hostname: '127.0.0.1', action: 'contact' })
    : Response.json({ id: 'local-preview-no-email-sent' })
});
const env = {
  CONTACT_ENABLED: 'true', RESEND_API_KEY: 'LOCAL_PREVIEW_ONLY', TURNSTILE_SECRET_KEY: 'LOCAL_PREVIEW_ONLY',
  RECIPIENT_EMAILS: 'preview@example.test', RESEND_FROM_EMAIL: 'Seedgression <preview@example.test>', REPLY_TO_EMAIL: 'preview@example.test',
  CONTACT_LIMITER: { limit: async () => ({ success: true }) }, EMAIL_LIMITER: { limit: async () => ({ success: true }) },
  ASSETS: { async fetch(request) {
    const url = new URL(request.url);
    const relative = decodeURIComponent(url.pathname).replace(/^\/+/, '');
    const path = resolve(root, relative);
    if (!path.startsWith(root + '/')) return new Response('Not found', { status: 404 });
    try { return new Response(await readFile(path), { headers: { 'Content-Type': types[extname(path)] || 'application/octet-stream' } }); }
    catch { return new Response(await readFile(resolve(root, '404.html')), { status: 404, headers: { 'Content-Type': 'text/html; charset=utf-8' } }); }
  } }
};
const server = http.createServer(async (req, res) => {
  try {
    if (req.headers.host !== `127.0.0.1:${port}` && req.headers.host !== `localhost:${port}`) { res.writeHead(403); res.end(); return; }
    const chunks = []; let length = 0;
    for await (const chunk of req) { length += chunk.length; if (length > 32768) { res.writeHead(413); res.end(); return; } chunks.push(chunk); }
    let body = chunks.length ? Buffer.concat(chunks) : undefined;
    if (req.url === '/api/contact' && body) {
      try { const data = JSON.parse(body); data.turnstileToken = 'local-preview-token'; body = JSON.stringify(data); } catch { /* Pass malformed requests to validation. */ }
    }
    const headers = new Headers(req.headers); headers.delete('content-length');
    const request = new Request(`${origin}${req.url}`, { method: req.method, headers, ...(body ? { body } : {}) });
    let response = await worker.fetch(request, env, { waitUntil: promise => promise.catch(() => {}) });
    if (req.url === '/api/config' || (req.url === '/api/contact' && response.ok)) {
      const data = await response.json();
      response = new Response(JSON.stringify({ ...data, preview: true }), { status: response.status, headers: response.headers });
    }
    res.writeHead(response.status, Object.fromEntries(response.headers));
    res.end(Buffer.from(await response.arrayBuffer()));
  } catch { res.writeHead(500); res.end('Local preview error.'); }
});
server.listen(port, '127.0.0.1', () => console.log(`Local preview: ${origin}\nAll email and automation calls are mocked. No external messages will be sent.`));
