import { readFile, readdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import settings from '../public/site-config.js';
import { validEmail } from '../public/validation.js';

const root = resolve(import.meta.dirname, '..');
const failures = [];
const fail = message => failures.push(message);
for (const dir of ['src', 'public', 'scripts']) {
  for (const name of await readdir(resolve(root, dir))) {
    if (!/\.(mjs|js)$/.test(name)) continue;
    const check = spawnSync(process.execPath, ['--check', resolve(root, dir, name)], { encoding: 'utf8' });
    if (check.status) fail(`${dir}/${name}: ${check.stderr}`);
  }
}
for (const key of ['contactEmail', 'privacyContact']) if (settings[key] && !validEmail(settings[key])) fail(`Invalid ${key} in public/site-config.js`);
if (settings.siteUrl) {
  try { const u = new URL(settings.siteUrl); if (u.protocol !== 'https:' || u.origin !== settings.siteUrl || u.username || u.password) throw new Error(); }
  catch { fail('siteUrl must be an HTTPS origin without a trailing slash, path, or query.'); }
}
if (settings.calendlyUrl) {
  try { const u = new URL(settings.calendlyUrl); if (u.protocol !== 'https:' || !['calendly.com', 'www.calendly.com'].includes(u.hostname) || u.pathname === '/' || u.username || u.password) throw new Error(); }
  catch { fail('calendlyUrl must be the HTTPS URL of your Calendly event.'); }
}
if (Object.keys(settings).some(key => /secret|api.?key|password/i.test(key))) fail('Secrets must never be placed in public/site-config.js.');
const pages = ['index.html', 'how-it-works.html', 'contact.html', '404.html'];
for (const page of pages) {
  const content = await readFile(resolve(root, 'public', page), 'utf8');
  if ((content.match(/<h1[ >]/g) || []).length !== 1) fail(`${page} must have one H1.`);
  if (!content.includes('name="description"')) fail(`${page} is missing a description.`);
  if (/contact\.php|_vercel|data-count=|\$2,400|4 partner slots|Live in 21/i.test(content)) fail(`${page} contains legacy launch content.`);
  for (const [, target] of content.matchAll(/(?:href|src)="([^"#]+)(?:#[^"]*)?"/g)) {
    if (/^(https?:|mailto:|data:|\/api\/)/.test(target)) continue;
    try { await readFile(resolve(root, 'public', target.replace(/^\//, ''))); }
    catch { fail(`${page}: missing file ${target}`); }
  }
}
if (failures.length) { console.error(failures.join('\n')); process.exit(1); }
console.log('Source syntax, page metadata, local links, and public settings passed.');
const missing = Object.entries(settings).filter(([k,v]) => !v && k !== 'privacyContact').map(([k]) => k);
if (missing.length) console.log('Set before launch: ' + missing.join(', ') + '.');
