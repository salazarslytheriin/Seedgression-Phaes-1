# Seedgression Phase 1 validation

Completed 13 September 2026. The source is ready for configuration and deployment; it has not been connected to live credentials or published.

## Completed checks

| Check | Result |
| --- | --- |
| Source syntax, page metadata and internal file links | Passed |
| Backend tests | 19 passed, external services mocked |
| Form interaction tests | 6 passed using JSDOM; these do not render a browser layout |
| Cloudflare deployment dry run | Passed with Wrangler 4.131.1 |
| Wrangler local runtime | Home, How It Works, Contact, CSS, API config, robots, legacy redirect and nested 404 returned expected responses |
| Local preview submission | Accepted through the preview server; notification and receipt services mocked |
| Desktop and mobile appearance | Saved renders of all three pages at 1440px and 390px reviewed; no obvious clipping or overlap |
| PDF setup guide | Rendered and visually reviewed |

The form tests cover retained text after failure, stable IDs for unchanged retries, fresh tokens before production retries, new IDs for edited enquiries, inline validation, disabled setup, acknowledgement failures, configured booking/email links and the mobile menu's Escape action.

A regression check exposed an error message disappearing when the security widget refreshed after an unsuccessful submission. The fix preserves the submission failure explanation until the visitor retries.

The backend tests cover email destinations and Reply-To, escaped visitor content, duplicate-send keys, input validation, request-size limits, origin checks, spam controls, rate limits, provider failures, optional webhook authentication/retries and public config secrecy.

## Practical limits

The saved page previews were generated before the final error-message JavaScript change and a small mobile text-spacing correction. They represent the delivered design; those two final corrections are in the source. The current browser session could not open the local preview, so a fresh end-to-end browser run after that change was not completed. JSDOM tests verify form behaviour but cannot verify browser rendering, real Turnstile execution or device-specific behaviour.

Resend acceptance is different from inbox delivery. The tests do not verify the real sending domain, API credentials, email delivery, calendar availability, Calendly notifications, DNS or optional automation destination. Those settings belong to your accounts and must be checked after configuration.

Unchanged retries on the same open page reuse Resend idempotency keys. Resend retains these for 24 hours. Refreshing the page or changing the enquiry creates a new submission. The automation receiver must deduplicate event IDs; the optional webhook has no durable delivery queue.

## After configuration

1. Submit one enquiry using a test inbox you control. Verify both delivered emails and their Reply-To behaviour.
2. Open the site on a phone and desktop. Check the menu, form errors, security widget and recovery after a failed submission.
3. Book a test Calendly appointment and check calendar availability and notifications.
4. If automation is enabled, verify authentication and that a repeated event ID does not repeat the business action.
5. Check the final domain, privacy details, canonical links, robots.txt and sitemap.xml.

Run `npm test` and `npm run build` after future code changes. Setup and publishing commands are in `SETUP-GUIDE.md` and the accompanying PDF.

Provider reference: https://resend.com/docs/dashboard/emails/idempotency-keys
