# Seedgression Phase 1 setup guide

This guide explains how to preview, configure, publish, and maintain the Seedgression launch website. The recommended setup is a static website with a Cloudflare Worker, Resend, and a Calendly booking link. It provides the requested contact and scheduling features without a PHP server or a WordPress installation.

The code is ready for configuration. Your live credentials, inbox addresses, Calendly event, final domain, and business privacy details have not been invented. No production website has been deployed and no live email has been sent during development.

## 1 The website and the platform choice

The final reference is **Seedgression-main.zip**, following your correction. The design retains its dark blue background, blue and teal accents, Sora typography, italic serif emphasis, hummingbird logo, and engine concept. The supplied Phase 1 sitemap defines three main pages: Home, How It Works, and Contact. There is also a technical 404 page.

The homepage introduces Acquire, Convert, and Retain and guides visitors deeper into the website. The detailed explanation lives on How It Works. Contact contains four fields: name, optional company, email, and message. It also includes the booking link and a short explanation of how enquiry data is used.

Pricing tiers, service configurators, unverified revenue figures, retention percentages, invented testimonials, limited-slot claims, and fixed delivery promises have been removed from the launch version. These can return in Phase 2 when the owner has approved the underlying facts and offer.

**Why this option fits:** there are only three marketing pages, and you are comfortable changing code and settings. Static files are straightforward to edit and the Worker handles the small amount of server-side work. No content database, WordPress plugins, Laravel application, or visual-builder subscription is needed for this scope. Provider usage limits and billing still apply; check the plans on your own accounts.

The trade-off is that there is no visual editing dashboard. You edit HTML for page content and CSS for appearance, then redeploy. If the owner later needs to edit content every day without code, revisit a CMS. Section 9 explains the WordPress path.

## 2 Preview the site on your computer

Extract the complete ZIP first. Install Node.js 24 LTS, version 24.15 or later in the 24.x series, with npm. Open a terminal in the extracted `seedgression-phase1` folder. You should see `package.json` and `wrangler.jsonc` in that folder.

Run these commands one at a time:

```sh
npm ci
npm run preview
```

Open `http://127.0.0.1:8788`. Home, How It Works, and Contact work locally. Try the form with a test address. The success message explicitly says no email was sent.

This preview runs the real validation and email-building code against fake external services. It is for design and interaction checks. It does not validate a real Resend key, a real Turnstile token, or a real webhook. Nothing is saved to a lead database. The preview script is outside `public/` and is never included in the deployed Worker.

Stop the server with Ctrl+C. Use `npm run dev` for Wrangler’s actual local Worker runtime. If automatic port discovery fails on your machine, try:

```sh
npm run dev -- --ip 127.0.0.1 --port 8787 --inspector-port 9230
```

Open `http://127.0.0.1:8787`. With the shipped settings, the form stays disabled. Local secrets can be supplied by copying `.dev.vars.example` to `.dev.vars`. Do not commit that file. Using real secrets in Wrangler can send real emails, unlike `npm run preview`.

## 3 Configure the public settings

Open `public/site-config.js`. These values are visible to website visitors; never paste a private API key into this file.

| Setting | What to enter |
| --- | --- |
| `siteUrl` | Final HTTPS website origin, such as `https://seedgression.com`, with no trailing slash |
| `contactEmail` | An existing inbox monitored by the agency |
| `calendlyUrl` | The complete URL of your Calendly event |
| `turnstileSiteKey` | The public site key from your Cloudflare Turnstile widget |
| `privacyContact` | Optional privacy inbox; otherwise `contactEmail` is used |

The domain in this guide is an example consistent with the brand, not a claim that DNS or ownership has been verified here. Use the actual domain you will connect.

Save the file after editing. Run `npm run check` to catch invalid URLs or addresses. Blank values are permitted during preparation. The guide and check output tell you what still needs configuration.

The production origin controls canonical links, the XML sitemap, and search indexing. Requests on other hostnames, including the temporary workers.dev address, receive a noindex header. Keep `siteUrl` blank during owner review; set it to the connected final origin when ready to launch.

## 4 Connect Resend and your business inbox

You need a Resend account, a sending domain verified in Resend, and an API key authorised to send from that domain. You also need an ordinary business inbox that someone checks.

Resend is used here for outgoing website emails. Replies arrive in your existing mailbox because the messages set Reply-To. This implementation does not create a mailbox, configure Resend inbound receiving, or replace Google Workspace.

In Resend, add the sending domain or a dedicated sending subdomain and follow the DNS instructions Resend supplies. A sending subdomain can separate website sending from your normal business mailbox. Use the exact record names and values shown by Resend. Keep existing Google Workspace MX records; do not replace them with website-email settings. Do not create multiple competing SPF records at the same DNS name.

Once the domain shows as verified, open `wrangler.jsonc` and fill in the `vars` section:

| Variable | Purpose |
| --- | --- |
| `CONTACT_ENABLED` | Keep `false` during preparation; change to `true` when the setup is ready |
| `RECIPIENT_EMAILS` | Agency notification recipients, separated by commas; maximum 10 |
| `RESEND_FROM_EMAIL` | Verified sender, for example `Seedgression <hello@mail.seedgression.com>` |
| `REPLY_TO_EMAIL` | Existing monitored agency inbox used for replies to the acknowledgement |

The addresses above are examples. They must exist or be valid senders in your actual setup. Do not use Resend’s shared onboarding sender for the public launch: it is intended for restricted testing.

When the form is submitted, the Worker validates it, verifies Turnstile, and asks Resend to send the agency notification. That notification includes the enquiry and the visitor’s email as Reply-To. It then sends a separate, fixed acknowledgement to the visitor, with the agency inbox as Reply-To. The visitor’s free text is not reflected into the automated acknowledgement.

Acceptance by Resend is not a guarantee of inbox delivery. Check the Resend dashboard for delivery failures or bounces. If the agency notification fails, the form reports an error and retains the visitor’s message. If only the acknowledgement fails, the enquiry remains successful and the page explains that the acknowledgement could not be sent.

## 5 Configure spam protection and booking

In Cloudflare, create a **Turnstile** widget in Managed mode. Add the exact hostnames where the form will run, including the final domain and the temporary Worker hostname if you want to test there. Copy its public site key into `public/site-config.js`. Its secret key belongs in Cloudflare secrets, described in the next section.

The backend checks the token’s success, hostname, and `contact` action. It also checks request origin, validates all fields, caps request size, uses a honeypot, and applies rate limits. Keep the two `ratelimits` bindings in `wrangler.jsonc`. Their namespace IDs should be unique within your Cloudflare account if you do not want to share counters with another Worker.

The default limits are ten attempts per minute per IP and three per minute per email at a Cloudflare location. These are abuse controls rather than a globally exact quota. Shared office networks can share the IP limit. Change the limits only if real traffic gives you a reason.

For booking, create a Calendly event, connect the appropriate calendar inside Calendly, and set the event’s availability, time zone, duration, location, and booking notifications. Paste the event URL into `calendlyUrl`.

The website opens the real Calendly event in a new tab. This keeps the page light and does not load a third-party calendar before the visitor chooses to book. Calendly manages availability and calendar invitations. This code does not detect completed bookings or send appointment confirmations through Resend. Those would need a separate, verified Calendly webhook integration if you later want custom automations.

## 6 Publish to Cloudflare Workers

This package targets **Cloudflare Workers with static assets**. It is not a Cloudflare Pages Functions package. Do not drag only the `public` folder into a static hosting upload and expect the contact API to work.

In `wrangler.jsonc`, keep or change the Worker name `seedgression-phase1`. Keep the entry point, asset binding, and rate-limit bindings. Choose a new Worker name if you want to review this version alongside the existing websites.

Run these commands from the project folder:

```sh
npx wrangler login
npm run build
npm run deploy
npx wrangler secret put RESEND_API_KEY
npx wrangler secret put TURNSTILE_SECRET_KEY
```

`wrangler login` opens Cloudflare’s authentication flow. `build` validates and bundles without publishing. `deploy` publishes the Worker and the public assets together. Each `secret put` command prompts for the value; paste it into that prompt. Never add secrets to `site-config.js`, HTML, or `wrangler.jsonc`.

The initial deployment can safely keep `CONTACT_ENABLED` false. After the sender, recipients, Turnstile widget, and secrets are configured, change it to `true` in `wrangler.jsonc` and run `npm run deploy` again. If anything required is still missing, the form remains unavailable instead of showing a fake success.

Cloudflare will display the Worker URL after deployment. In the Worker’s domain settings, add your final custom domain. Follow Cloudflare’s domain and zone setup if your domain is not yet available there. When changing DNS providers, preserve the existing email and other required DNS records. Set `siteUrl` to the exact final HTTPS origin and redeploy.

For future Git-based deployments, import this project into a repository and connect it through Cloudflare Workers Builds. Use the repository root containing `wrangler.jsonc`. Install with `npm ci`; the deployment command is `npm run deploy`. Keep source-controlled non-secret variables in `wrangler.jsonc` to avoid dashboard values being overwritten unexpectedly. Cloudflare secrets stay outside the repository.

## 7 Add an optional automation

The contact form can send a `lead.created` event to one HTTPS webhook after the agency notification is accepted. This is disabled when `AUTOMATION_WEBHOOK_URL` is empty. You do not need it for forms or emails to work.

For n8n, create a Webhook node using POST and Header Auth. Configure its expected header as `Authorization` with the value `Bearer YOUR_SHARED_SECRET`. Connect the nodes you want, activate the workflow, and use its production webhook URL.

Add the two optional secrets in Cloudflare:

```sh
npx wrangler secret put AUTOMATION_WEBHOOK_URL
npx wrangler secret put AUTOMATION_WEBHOOK_SECRET
```

Use the same shared secret that the receiving workflow expects, without the `Bearer ` prefix in the Cloudflare secret value. The Worker adds that prefix itself. Avoid endpoints that redirect; redirects are refused.

The JSON body has this structure:

```json
{
  "event": "lead.created",
  "event_id": "lead/<reference>/<payload-hash>",
  "lead_id": "<enquiry-reference>",
  "occurred_at": "<server-time-in-UTC>",
  "source": "https://your-domain.com",
  "lead": {
    "name": "Example Prospect",
    "company": "Example Company",
    "email": "prospect@example.com",
    "message": "The enquiry text"
  }
}
```

Use `event_id` to reject events already processed before writing to a CRM or sending anything. A visitor retry or a delivery retry can repeat an event. The same ID is also supplied in the `Idempotency-Key` request header. In n8n, access the submitted fields under the Webhook node’s `body` object.

This is a lightweight integration: there is one bounded retry for transient webhook errors and no durable queue or database. A failed webhook does not discard the emailed enquiry. Failures are logged by enquiry reference. For business-critical automation, add a durable queue or outbox and receiving-side deduplication before relying on guaranteed processing.

Update the privacy explanation on the Contact page to name the CRM or automation service you actually enable and how it is used. Form submission does not subscribe a person to marketing. Any later promotional sequence needs its own appropriate signup flow.

## 8 Edit content and troubleshoot

Page content is in `public/index.html`, `public/how-it-works.html`, and `public/contact.html`. Navigation and footer markup are repeated across the pages so the source stays simple; update all pages, including `404.html`, when changing those shared links. Appearance is in `public/styles.css`. Fonts are self-hosted under `public/assets/fonts/`, with their licence files included. The logo comes from the approved reference.

Email copy lives in `src/emails.js`. Keep the visitor email in Reply-To on the agency notification, not as the From sender. Preserve HTML escaping for submitted text. Do not paste the visitor’s message into the automatic acknowledgement.

After edits, run:

```sh
npm run check
npm test
npm run build
npm run deploy
```

| Symptom | Check |
| --- | --- |
| Form is unavailable | `CONTACT_ENABLED`, public site key, both secrets, sender, recipients, Reply-To, and rate-limit bindings |
| Security check fails | Turnstile hostnames, site key and secret pairing, browser blockers, and fresh token |
| Resend rejects an enquiry | Verified sender/domain, API-key permissions, recipients, provider limits, and logs |
| Agency received it but prospect did not | Resend delivery/bounce status and `receipt_failed` log entry |
| Booking says available soon | A valid Calendly event URL in `site-config.js`, then redeploy |
| Form returns 404 | Deploy the whole Worker project; static assets alone do not include the API |
| Site is not being indexed | Final custom domain, exact `siteUrl`, canonical origin, robots.txt, and noindex headers |
| Automation did not run | Production webhook URL, shared secret, active workflow, response status, and `automation_failed` logs |

Use `npm run logs` for live Worker logs. The application logs event names and references rather than message contents or API keys. Resend and your business mailbox still process and retain emails according to their settings. A successful API call only confirms provider acceptance; check delivery separately.

Resend idempotency keys protect unchanged retries for 24 hours. The browser retains the same enquiry ID while retrying unchanged content on the same open page. Refreshing the page starts a new ID, and there is no permanent server-side deduplication. This limitation is deliberate for the small Phase 1 setup.

To temporarily stop new enquiries, change `CONTACT_ENABLED` to `false` and redeploy. Keep the public email link available. To reverse a bad release, use Cloudflare’s deployment rollback or redeploy the last known-good source. Keep secrets out of downloaded backups and Git.

## 9 If you want WordPress later

The delivered files do not install through WordPress Appearance or Plugins. There is no PHP theme in this package because the chosen deployment uses Cloudflare Workers.

A conventional WordPress site needs PHP, MySQL or MariaDB, and compatible hosting. Cloudflare can sit in front of that host for DNS, CDN, and security. Cloudflare Workers static hosting by itself is not that WordPress environment.

If visual editing becomes a requirement, choose WordPress hosting first, then turn the approved layouts into a custom block theme or carefully build them in your chosen page editor. Keep the page structure and branding, configure server-side email through Resend or a suitable integration, and keep the Calendly event link. That migration is a separate implementation and should be tested for forms, caching, updates, and editing permissions.

A headless WordPress setup is also possible: WordPress supplies content to a separate frontend. It introduces two systems to manage and is unnecessary for this three-page launch. Webflow can make sense for visual editing, while Laravel makes sense for a more substantial application. Neither is needed just to provide these three pages and integrations.

## 10 Launch review and next phase

Before public launch, configure the final domain, monitored email addresses, verified sender, Resend and Turnstile secrets, allowed hostnames, and Calendly event. Complete the business privacy information for the actual organisation, including the responsible entity, contact route, retention decisions, and any applicable disclosures. The supplied short notice describes the default implementation; it is not a completed jurisdiction-specific legal policy.

Make one genuine test enquiry using an inbox you control. Check the agency notification, prospect acknowledgement, Reply-To behaviour, and Resend delivery status. Make a test booking in Calendly and confirm calendar availability and notifications. If you enable automation, confirm one event produces one intended record and that duplicates do not repeat the action.

Open Home, How It Works, Contact, and an unknown URL on desktop and mobile. Check navigation, keyboard focus, field errors, failure recovery, the booking link, and privacy access. Check the production robots.txt and sitemap.xml after setting the final origin.

For Phase 2, add service depth and interactive elements only after the offer is defined. Publish pricing tiers only when their scope is settled, and add proof only from real engagements approved for publication. The launch code leaves room for more static pages and a richer backend later.

## Official references

The implementation was checked against these vendor documents. Consult them if dashboard labels or account features change.

- Cloudflare static assets: https://developers.cloudflare.com/workers/static-assets/
- Wrangler configuration: https://developers.cloudflare.com/workers/wrangler/configuration/
- Worker secrets: https://developers.cloudflare.com/workers/configuration/secrets/
- Turnstile server validation: https://developers.cloudflare.com/turnstile/get-started/server-side-validation/
- Worker rate limits: https://developers.cloudflare.com/workers/runtime-apis/bindings/rate-limit/
- Resend with Workers: https://resend.com/docs/send-with-cloudflare-workers
- Resend idempotency: https://resend.com/docs/dashboard/emails/idempotency-keys
- Calendly embedding options: https://calendly.com/help/embed-options-overview
- WordPress requirements: https://wordpress.org/about/requirements/
