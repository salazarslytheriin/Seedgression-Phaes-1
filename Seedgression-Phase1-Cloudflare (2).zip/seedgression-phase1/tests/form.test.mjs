import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { Script } from 'node:vm';
import { setImmediate as nextTick } from 'node:timers/promises';
import { JSDOM } from 'jsdom';
import { validateInput, validEmail } from '../public/validation.js';

const html = await readFile(new URL('../public/contact.html', import.meta.url), 'utf8');
const app = (await readFile(new URL('../public/app.js', import.meta.url), 'utf8')).replace(/^import .+;\n/gm, '');

async function setup(t, { preview = true, ready = true, provider, settings = {} } = {}) {
  const dom = new JSDOM(html, { url: 'https://seedgression.test/contact.html', runScripts: 'outside-only' });
  t.after(() => dom.window.close());
  const w = dom.window, requests = [];
  let widget;
  Object.assign(w, {
    settings: { contactEmail: '', privacyContact: '', calendlyUrl: '', turnstileSiteKey: 'test-key', ...settings },
    validateInput, validEmail, AbortSignal,
    matchMedia: () => ({ matches: true, addEventListener() {} }),
    fetch: async (url, init) => {
      if (url === '/api/config') return Response.json({ formReady: ready, preview });
      const data = JSON.parse(init.body); requests.push(data);
      return provider ? provider(data, requests.length) : Response.json({ ok: true, preview, receiptAccepted: true, reference: data.submissionId });
    },
    turnstile: { render(selector, config) { widget = config; return 0; }, reset() { /* A fresh test token is supplied explicitly by each test. */ } }
  });
  new Script(app).runInContext(dom.getInternalVMContext());
  await nextTick();
  const q = selector => w.document.querySelector(selector);
  if (!preview && ready) q('script[src*="turnstile"]').dispatchEvent(new w.Event('load'));
  function fill() {
    for (const [id, value] of Object.entries({ name: 'Test Prospect', email: 'qa@example.test', message: 'Please help us connect our website and marketing.' })) {
      q('#' + id).value = value;
      q('#' + id).dispatchEvent(new w.Event('input', { bubbles: true }));
    }
  }
  async function submit() { q('#contact-form').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true })); await nextTick(); }
  return { w, q, fill, submit, requests, token: value => widget.callback(value) };
}

test('preview failure preserves text and retries with the same enquiry ID', async t => {
  const h = await setup(t, { provider: (data, count) => count === 1
    ? Response.json({ ok: false, message: 'Please try again.' }, { status: 502 })
    : Response.json({ ok: true, preview: true, reference: data.submissionId }) });
  h.fill(); await h.submit();
  assert.match(h.q('#form-status').textContent, /try again/);
  assert.equal(h.q('#contact-form').hidden, false);
  assert.ok(h.q('#message').value.length > 10);
  assert.equal(h.q('button[type=submit]').disabled, false);
  await h.submit();
  assert.equal(h.requests[0].submissionId, h.requests[1].submissionId);
  assert.equal(h.q('#form-success').hidden, false);
  assert.match(h.q('#success-message').textContent, /No email was sent/);
});

test('production retry waits for a fresh token and preserves the failure explanation', async t => {
  const h = await setup(t, { preview: false, provider: (data, count) => {
    if (count === 1) throw new TypeError('Network error');
    return Response.json({ ok: true, receiptAccepted: true, reference: data.submissionId });
  } });
  h.fill(); h.token('first-test-token'); await h.submit();
  assert.equal(h.q('button[type=submit]').disabled, true);
  assert.match(h.q('#form-status').textContent, /could not confirm/);
  h.token('fresh-test-token');
  assert.equal(h.q('button[type=submit]').disabled, false);
  assert.match(h.q('#form-status').textContent, /could not confirm/);
  await h.submit();
  assert.equal(h.requests[0].submissionId, h.requests[1].submissionId);
  assert.equal(h.requests[1].turnstileToken, 'fresh-test-token');
  assert.equal(h.q('#form-success').hidden, false);
});

test('editing an unsuccessful enquiry creates a new ID', async t => {
  const h = await setup(t, { provider: () => Response.json({ ok: false }, { status: 502 }) });
  h.fill(); await h.submit(); h.q('#message').value += ' Additional details.'; await h.submit();
  assert.notEqual(h.requests[0].submissionId, h.requests[1].submissionId);
});

test('validation and unavailable configuration cannot report success', async t => {
  const h = await setup(t); await h.submit();
  assert.equal(h.requests.length, 0);
  assert.equal(h.q('#name').getAttribute('aria-invalid'), 'true');
  const unavailable = await setup(t, { ready: false }); unavailable.fill(); await unavailable.submit();
  assert.equal(unavailable.requests.length, 0);
  assert.equal(unavailable.q('button[type=submit]').disabled, true);
  assert.equal(unavailable.q('#form-success').hidden, true);
});

test('acknowledgement failure tells visitors their enquiry was still submitted', async t => {
  const h = await setup(t, { provider: () => Response.json({ ok: true, receiptAccepted: false }) });
  h.fill(); await h.submit();
  assert.equal(h.q('#form-success').hidden, false);
  assert.match(h.q('#success-message').textContent, /do not need to submit again/);
});

test('configured booking and email links appear and mobile menu closes with Escape', async t => {
  const h = await setup(t, { settings: { contactEmail: 'team@example.test', calendlyUrl: 'https://calendly.com/example/discovery' } });
  assert.equal(h.q('#booking-link').hidden, false);
  assert.equal(h.q('#booking-link').href, 'https://calendly.com/example/discovery');
  assert.equal(h.q('[data-contact-email]').href, 'mailto:team@example.test');
  h.q('.menu-toggle').click(); assert.equal(h.q('.menu-toggle').getAttribute('aria-expanded'), 'true');
  h.w.document.dispatchEvent(new h.w.KeyboardEvent('keydown', { key: 'Escape' }));
  assert.equal(h.q('.menu-toggle').getAttribute('aria-expanded'), 'false');
});
