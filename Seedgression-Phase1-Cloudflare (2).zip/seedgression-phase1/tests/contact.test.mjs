import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorker } from '../src/worker.js';
import { validateInput } from '../public/validation.js';

const origin = 'https://seedgression.com';
const settings = { siteUrl: origin, contactEmail: '', calendlyUrl: '', turnstileSiteKey: 'test-site-key' };
const lead = { name: 'Test Prospect', company: 'Example', email: 'prospect@example.test', message: 'I would like to discuss our website and customer journey.', website: '', submissionId: 'ebc0a762-e642-4c81-81f7-35e42d5ef981', turnstileToken: 'token' };
function harness(options = {}) {
  const calls = [], logs = [], pending = [];
  const env = {
    CONTACT_ENABLED: 'true', RESEND_API_KEY: 'server-secret', TURNSTILE_SECRET_KEY: 'turnstile-secret',
    RECIPIENT_EMAILS: 'agency@example.test', RESEND_FROM_EMAIL: 'Seedgression <hello@example.test>', REPLY_TO_EMAIL: 'agency@example.test',
    CONTACT_LIMITER: { limit: async () => ({ success: true }) }, EMAIL_LIMITER: { limit: async () => ({ success: true }) },
    ASSETS: { fetch: async () => new Response('<html><head></head><body>Page</body></html>', { headers: { 'Content-Type': 'text/html' } }) }, ...options.env
  };
  const fetcher = async (url, init) => {
    const call = { url: String(url), headers: init.headers, body: JSON.parse(init.body) }; calls.push(call);
    if (call.url.includes('/siteverify')) return Response.json(options.verification || { success: true, hostname: 'seedgression.com', action: 'contact' });
    if (options.provider) return options.provider(call);
    return Response.json({ id: 'provider-email-id' });
  };
  const logger = { log: x => logs.push(x), error: x => logs.push(x) };
  const worker = createWorker({ settings, fetcher, logger });
  const invoke = (data = lead, headers = {}, method = 'POST', path = '/api/contact') => worker.fetch(new Request(origin + path, { method, headers: { Origin: origin, 'Content-Type': 'application/json', 'CF-Connecting-IP': '192.0.2.1', ...headers }, ...(method === 'POST' ? { body: typeof data === 'string' ? data : JSON.stringify(data) } : {}) }), env, { waitUntil: p => pending.push(p) });
  return { invoke, calls, logs, pending, worker, env };
}

test('valid enquiry sends agency notification, then a separate safe receipt', async () => {
  const h = harness(), res = await h.invoke(), result = await res.json();
  assert.equal(res.status, 200); assert.equal(result.ok, true); assert.equal(result.receiptAccepted, true);
  const emails = h.calls.filter(c => c.url.includes('api.resend'));
  assert.equal(emails.length, 2);
  assert.deepEqual(emails[0].body.to, ['agency@example.test']); assert.equal(emails[0].body.reply_to, lead.email);
  assert.deepEqual(emails[1].body.to, [lead.email]); assert.equal(emails[1].body.reply_to, 'agency@example.test');
  assert.ok(!emails[1].body.html.includes(lead.message)); assert.ok(!emails[1].body.html.includes(lead.name));
  assert.ok(!h.logs.join('').includes(lead.email)); assert.ok(!h.logs.join('').includes(lead.message));
});
test('HTML in visitor data is escaped in the notification and absent from receipt', async () => {
  const h = harness(); await h.invoke({ ...lead, name: '<img src=x>', message: '<script>alert(1)</script> This is a test.' });
  const emails = h.calls.filter(c => c.url.includes('api.resend'));
  assert.ok(emails[0].body.html.includes('&lt;script&gt;')); assert.ok(!emails[0].body.html.includes('<script>'));
  assert.ok(!emails[1].body.html.includes('img src'));
});
test('unchanged retries produce identical provider payloads and idempotency keys', async () => {
  const h = harness(); await h.invoke(); await h.invoke({ ...lead, turnstileToken: 'fresh-token' });
  const e = h.calls.filter(c => c.url.includes('api.resend'));
  assert.deepEqual(e[0], e[2]); assert.deepEqual(e[1], e[3]);
});
test('edited enquiry gets a different idempotency key even if client ID is reused', async () => {
  const h = harness(); await h.invoke(); await h.invoke({ ...lead, message: lead.message + ' More context.' });
  const e = h.calls.filter(c => c.url.includes('api.resend'));
  assert.notEqual(e[0].headers['Idempotency-Key'], e[2].headers['Idempotency-Key']);
});
test('invalid fields, control characters, and oversized values are blocked before email', async () => {
  for (const patch of [{ email: 'bad' }, { email: 'test@example.test\r\nBcc: bad@example.test' }, { name: 'a\nb' }, { message: 'short' }, { company: 'x'.repeat(151) }, { name: ['bad'] }]) {
    const h = harness(), res = await h.invoke({ ...lead, ...patch });
    assert.equal(res.status, 422); assert.equal(h.calls.length, 0);
  }
});
test('optional company and international names are accepted', () => {
  assert.equal(validateInput({ name: 'يحيى Sahnoun', email: lead.email, message: lead.message }).valid, true);
});
test('honeypot submissions send no emails or webhook', async () => {
  const h = harness(), res = await h.invoke({ ...lead, website: 'spam' }); assert.equal(res.status, 200); assert.equal(h.calls.length, 0);
});
test('malformed JSON and oversized streamed body are rejected', async () => {
  const h = harness(); assert.equal((await h.invoke('{bad')).status, 400);
  assert.equal((await h.invoke('x'.repeat(32769))).status, 413); assert.equal(h.calls.length, 0);
});
test('wrong origin, content type, and method are rejected', async () => {
  const h = harness(); assert.equal((await h.invoke(lead, { Origin: 'https://attacker.test' })).status, 403);
  assert.equal((await h.invoke(lead, { 'Content-Type': 'text/plain' })).status, 415);
  assert.equal((await h.invoke(null, {}, 'GET')).status, 405); assert.equal(h.calls.length, 0);
});
test('missing secrets and disabled contact never report a successful submission', async () => {
  for (const env of [{ RESEND_API_KEY: '' }, { TURNSTILE_SECRET_KEY: '' }, { CONTACT_ENABLED: 'false' }, { REPLY_TO_EMAIL: '' }, { CONTACT_LIMITER: null }]) {
    const h = harness({ env }); assert.equal((await h.invoke()).status, 503); assert.equal(h.calls.length, 0);
  }
});
test('failed, wrong-host, and wrong-action Turnstile responses cannot send emails', async () => {
  for (const verification of [{ success: false }, { success: true, hostname: 'attacker.test', action: 'contact' }, { success: true, hostname: 'seedgression.com', action: 'other' }]) {
    const h = harness({ verification }); assert.equal((await h.invoke()).status, 422); assert.equal(h.calls.length, 1);
  }
});
test('rate limits prevent emails and include Retry-After', async () => {
  const h = harness({ env: { EMAIL_LIMITER: { limit: async () => ({ success: false }) } } });
  const res = await h.invoke(); assert.equal(res.status, 429); assert.equal(res.headers.get('Retry-After'), '60'); assert.equal(h.calls.length, 1);
});
test('notification failure stops receipt and automation, preserving retry semantics', async () => {
  const h = harness({ provider: () => new Response('error', { status: 503 }), env: { AUTOMATION_WEBHOOK_URL: 'https://automation.example.test/hook', AUTOMATION_WEBHOOK_SECRET: 'secret' } });
  const res = await h.invoke(); assert.equal(res.status, 502); assert.equal(h.calls.length, 2); assert.equal(h.pending.length, 0);
});
test('receipt failure keeps the accepted enquiry successful and records partial failure', async () => {
  const h = harness({ provider: call => call.body.to[0] === lead.email ? new Response('error', { status: 503 }) : Response.json({ id: 'accepted' }) });
  const res = await h.invoke(), data = await res.json(); assert.equal(res.status, 200); assert.equal(data.receiptAccepted, false);
  assert.equal(h.calls.length, 4); assert.ok(h.logs.some(l => l.includes('receipt_failed')));
});
test('optional automation is authenticated and includes stable event and lead IDs', async () => {
  const h = harness({ env: { AUTOMATION_WEBHOOK_URL: 'https://automation.example.test/hook', AUTOMATION_WEBHOOK_SECRET: 'hook-secret' } });
  await h.invoke(); await Promise.all(h.pending);
  const call = h.calls.find(c => c.url.includes('automation.'));
  assert.equal(call.headers.Authorization, 'Bearer hook-secret'); assert.equal(call.body.event, 'lead.created');
  assert.equal(call.body.lead_id, lead.submissionId); assert.equal(call.headers['Idempotency-Key'], call.body.event_id);
  assert.equal(call.body.lead.message, lead.message);
});
test('failed automation retries once and does not invalidate accepted enquiry', async () => {
  const h = harness({ env: { AUTOMATION_WEBHOOK_URL: 'https://automation.example.test/hook', AUTOMATION_WEBHOOK_SECRET: 'hook-secret' }, provider: call => call.url.includes('automation.') ? new Response('error', { status: 503 }) : Response.json({ id: 'accepted' }) });
  const res = await h.invoke(); await Promise.all(h.pending); assert.equal(res.status, 200);
  assert.equal(h.calls.filter(c => c.url.includes('automation.')).length, 2); assert.ok(h.logs.some(l => l.includes('automation_failed')));
});
test('public config never exposes secrets or private recipients', async () => {
  const h = harness(), res = await h.invoke(null, {}, 'GET', '/api/config'), data = await res.text();
  assert.deepEqual(JSON.parse(data), { formReady: true }); assert.ok(!data.includes('server-secret')); assert.ok(!data.includes('agency@'));
});
test('legacy links redirect and sitemap only lists the three launch pages', async () => {
  const h = harness();
  const redirect = await h.invoke(null, {}, 'GET', '/engine.html'); assert.equal(redirect.status, 301); assert.equal(redirect.headers.get('Location'), origin + '/how-it-works.html');
  const sitemap = await (await h.invoke(null, {}, 'GET', '/sitemap.xml')).text(); assert.equal((sitemap.match(/<url>/g) || []).length, 3);
  const page = await h.invoke(null, {}, 'GET', '/'); assert.ok((await page.text()).includes('rel="canonical"')); assert.ok(page.headers.get('Content-Security-Policy').includes("frame-ancestors 'none'"));
});
test('preview origins are not indexed and unlisted API routes return 404', async () => {
  const h = harness();
  const res = await h.worker.fetch(new Request('https://preview.workers.dev/robots.txt'), h.env, {});
  assert.equal(await res.text(), 'User-agent: *\nDisallow: /\n'); assert.equal(res.headers.get('X-Robots-Tag'), 'noindex, nofollow');
  assert.equal((await h.invoke(null, {}, 'GET', '/api/unknown')).status, 404);
});
