import siteSettings from '../public/site-config.js';
import { validateInput, validEmail } from '../public/validation.js';
import { notificationEmail, receiptEmail, escapeHtml } from './emails.js';

const MAX_BODY = 32768;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const CSP = "default-src 'self'; script-src 'self' https://challenges.cloudflare.com; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self' https://challenges.cloudflare.com; frame-src https://challenges.cloudflare.com; frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; upgrade-insecure-requests";

function json(status, data, extra = {}) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra } });
}
function runtimeConfig(env) {
  const recipients = (env.RECIPIENT_EMAILS || '').split(',').map(s => s.trim()).filter(Boolean);
  const from = (env.RESEND_FROM_EMAIL || '').trim();
  const fromEmail = from.includes('<') ? from.match(/^[^<>\r\n]+<([^<>]+)>$/)?.[1] : from;
  return { recipients, from, fromEmail, replyTo: (env.REPLY_TO_EMAIL || '').trim() };
}
function formReady(env, settings) {
  const cfg = runtimeConfig(env);
  return env.CONTACT_ENABLED === 'true' && !!env.RESEND_API_KEY && !!env.TURNSTILE_SECRET_KEY &&
    !!settings.turnstileSiteKey && !!env.CONTACT_LIMITER && !!env.EMAIL_LIMITER &&
    validEmail(cfg.fromEmail) && !/[\r\n]/.test(cfg.from) && validEmail(cfg.replyTo) &&
    cfg.recipients.length > 0 && cfg.recipients.length <= 10 && cfg.recipients.every(validEmail);
}

async function readBody(request) {
  if (Number(request.headers.get('Content-Length')) > MAX_BODY) throw Object.assign(new Error('body'), { status: 413 });
  if (!request.body) throw Object.assign(new Error('body'), { status: 400 });
  const reader = request.body.getReader(), chunks = [];
  let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > MAX_BODY) { await reader.cancel(); throw Object.assign(new Error('body'), { status: 413 }); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  try {
    const data = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('object');
    return data;
  } catch { throw Object.assign(new Error('body'), { status: 400 }); }
}

async function hash(value) {
  const result = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return [...new Uint8Array(result)].map(x => x.toString(16).padStart(2, '0')).join('');
}

export function createWorker({ settings = siteSettings, fetcher = fetch, logger = console } = {}) {
  async function sendMail(payload, key, apiKey) {
    const response = await fetcher('https://api.resend.com/emails', {
      method: 'POST', redirect: 'error',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}`, 'Idempotency-Key': key },
      body: JSON.stringify(payload), signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) throw Object.assign(new Error('email_provider'), { status: response.status });
    const result = await response.json();
    if (typeof result.id !== 'string' || !result.id) throw new Error('email_response');
    return result.id;
  }

  async function sendAutomation(env, lead, reference, eventId, origin) {
    if (!env.AUTOMATION_WEBHOOK_URL) return;
    try {
      const url = new URL(env.AUTOMATION_WEBHOOK_URL);
      if (url.protocol !== 'https:' || url.username || url.password || !env.AUTOMATION_WEBHOOK_SECRET) throw new Error('automation_config');
      const payload = JSON.stringify({ event: 'lead.created', event_id: eventId, lead_id: reference, occurred_at: new Date().toISOString(), source: origin, lead });
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const res = await fetcher(url.href, {
            method: 'POST', redirect: 'error', signal: AbortSignal.timeout(5000),
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.AUTOMATION_WEBHOOK_SECRET}`, 'Idempotency-Key': eventId },
            body: payload
          });
          if (res.ok) return;
          if (res.status < 500 && res.status !== 429) break;
        } catch { /* One bounded retry; no private provider response is logged. */ }
      }
      logger.error(JSON.stringify({ event: 'automation_failed', reference }));
    } catch { logger.error(JSON.stringify({ event: 'automation_configuration_error', reference })); }
  }

  async function contact(request, env, ctx) {
    if (request.method !== 'POST') return json(405, { ok: false, message: 'Use the contact form to submit an enquiry.' }, { Allow: 'POST' });
    const url = new URL(request.url);
    if (request.headers.get('Origin') !== url.origin || request.headers.get('Sec-Fetch-Site') === 'cross-site') return json(403, { ok: false, message: 'Please submit the form from this website.' });
    if (request.headers.get('Content-Type')?.split(';')[0].trim().toLowerCase() !== 'application/json') return json(415, { ok: false, message: 'Please submit the form from this website.' });
    if (!formReady(env, settings)) return json(503, { ok: false, message: 'Online enquiries are not available yet. Please use our contact email or check back soon.' });
    // IP limit is deliberately generous for shared office networks; the second limit is per email.
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    if (!(await env.CONTACT_LIMITER.limit({ key: `contact:${ip}` })).success) return json(429, { ok: false, message: 'Too many attempts. Please wait a minute and try again.' }, { 'Retry-After': '60' });
    let input;
    try { input = await readBody(request); }
    catch (error) { return json(error.status || 400, { ok: false, message: error.status === 413 ? 'Your submission is too large.' : 'The form data could not be read. Please try again.' }); }
    if (typeof input.website !== 'undefined' && typeof input.website !== 'string') return json(400, { ok: false, message: 'Invalid form data.' });
    if (input.website?.trim()) return json(200, { ok: true, receiptAccepted: false, message: 'Thank you for your enquiry.' });
    const { valid, fields, errors } = validateInput(input);
    if (!valid) return json(422, { ok: false, message: 'Please check the highlighted fields.', errors });
    if (!UUID.test(input.submissionId || '')) return json(400, { ok: false, message: 'Please refresh the page and try again.' });
    if (typeof input.turnstileToken !== 'string' || !input.turnstileToken || input.turnstileToken.length > 2048) return json(422, { ok: false, message: 'Please complete the security check.' });
    let verified;
    try {
      const response = await fetcher('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(6000),
        body: JSON.stringify({ secret: env.TURNSTILE_SECRET_KEY, response: input.turnstileToken, ...(ip !== 'unknown' ? { remoteip: ip } : {}) })
      });
      if (!response.ok) throw new Error('turnstile');
      verified = await response.json();
    } catch { return json(503, { ok: false, message: 'The security check is unavailable. Please try again shortly.' }); }
    if (!verified.success || verified.hostname !== url.hostname || verified.action !== 'contact') return json(422, { ok: false, message: 'The security check expired or failed. Please complete it again.' });
    const emailHash = await hash(fields.email.toLowerCase());
    if (!(await env.EMAIL_LIMITER.limit({ key: `email:${emailHash}` })).success) return json(429, { ok: false, message: 'An enquiry was recently attempted with this email. Please wait a minute before trying again.' }, { 'Retry-After': '60' });
    const reference = input.submissionId.toLowerCase();
    const config = runtimeConfig(env);
    const notification = notificationEmail(fields, reference, config);
    const receipt = receiptEmail(fields, reference, config);
    // Hash the exact email payload as well as the reference. Unchanged retries have identical payloads and keys.
    const notificationKey = `enquiry/${reference}/${await hash(JSON.stringify(notification))}`;
    const receiptKey = `receipt/${reference}/${await hash(JSON.stringify(receipt))}`;
    try { await sendMail(notification, notificationKey, env.RESEND_API_KEY); }
    catch (error) {
      logger.error(JSON.stringify({ event: 'notification_failed', reference, status: error.status || 0 }));
      return json(502, { ok: false, message: 'We could not confirm your enquiry. Your message is still here; please try again.' });
    }
    let receiptAccepted = false;
    for (let attempt = 0; attempt < 2 && !receiptAccepted; attempt++) {
      try { await sendMail(receipt, receiptKey, env.RESEND_API_KEY); receiptAccepted = true; }
      catch (error) { if (attempt === 1) logger.error(JSON.stringify({ event: 'receipt_failed', reference, status: error.status || 0 })); }
    }
    logger.log(JSON.stringify({ event: 'enquiry_accepted', reference, receiptAccepted }));
    if (env.AUTOMATION_WEBHOOK_URL) {
      const eventId = `lead/${reference}/${await hash(JSON.stringify(fields))}`;
      ctx.waitUntil(sendAutomation(env, fields, reference, eventId, url.origin));
    }
    return json(200, { ok: true, reference, receiptAccepted });
  }

  async function route(request, env, ctx) {
    const url = new URL(request.url), path = url.pathname;
    if (path === '/api/contact') return contact(request, env, ctx);
    if (path === '/api/config') {
      if (request.method !== 'GET') return json(405, { ok: false }, { Allow: 'GET' });
      return json(200, { formReady: formReady(env, settings) });
    }
    if (path.startsWith('/api/')) return json(404, { ok: false, message: 'Not found.' });
    if (!['GET', 'HEAD'].includes(request.method)) return new Response('Method not allowed', { status: 405, headers: { Allow: 'GET, HEAD' } });
    const legacy = { '/engine.html': '/how-it-works.html', '/engine': '/how-it-works.html', '/apply.html': '/contact.html', '/apply': '/contact.html', '/contact': '/contact.html', '/how-it-works': '/how-it-works.html' };
    if (legacy[path]) return Response.redirect(`${url.origin}${legacy[path]}${url.search}`, 301);
    if (path === '/index.html') return Response.redirect(`${url.origin}/${url.search}`, 301);
    const finalOrigin = settings.siteUrl.replace(/\/$/, '');
    const isLive = finalOrigin && url.origin === finalOrigin;
    if (path === '/robots.txt') return new Response(isLive ? `User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: ${finalOrigin}/sitemap.xml\n` : 'User-agent: *\nDisallow: /\n', { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    if (path === '/sitemap.xml') {
      if (!isLive) return new Response('Sitemap available on the configured production domain.', { status: 404 });
      const routes = ['/', '/how-it-works.html', '/contact.html'];
      return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${routes.map(p => `<url><loc>${escapeHtml(finalOrigin + p)}</loc></url>`).join('')}</urlset>`, { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
    }
    let assetRequest = request;
    if (path === '/') { const assetURL = new URL(request.url); assetURL.pathname = '/index.html'; assetRequest = new Request(assetURL, request); }
    let response = await env.ASSETS.fetch(assetRequest);
    if (response.headers.get('Content-Type')?.includes('text/html')) {
      const html = await response.text();
      const canonical = isLive && response.status === 200 ? `<link rel="canonical" href="${escapeHtml(finalOrigin + path)}"><meta property="og:url" content="${escapeHtml(finalOrigin + path)}">` : '';
      const headers = new Headers(response.headers);
      headers.delete('Content-Length'); headers.delete('ETag');
      headers.delete('Content-Encoding');
      headers.set('Cache-Control', 'no-cache');
      response = new Response(html.replace('</head>', `${canonical}</head>`), { status: response.status, headers });
    }
    return response;
  }

  return {
    async fetch(request, env, ctx) {
      let response;
      try { response = await route(request, env, ctx); }
      catch { logger.error(JSON.stringify({ event: 'request_failed' })); response = json(500, { ok: false, message: 'Something went wrong. Please try again shortly.' }); }
      const headers = new Headers(response.headers);
      headers.set('Content-Security-Policy', CSP);
      headers.set('X-Content-Type-Options', 'nosniff');
      headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
      headers.set('X-Frame-Options', 'DENY');
      headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
      const url = new URL(request.url);
      if (url.protocol === 'https:') headers.set('Strict-Transport-Security', 'max-age=31536000');
      if (!settings.siteUrl || url.origin !== settings.siteUrl.replace(/\/$/, '') || response.status >= 400 || url.pathname.startsWith('/api/')) headers.set('X-Robots-Tag', 'noindex, nofollow');
      if (url.pathname.endsWith('/site-config.js')) headers.set('Cache-Control', 'no-store');
      return new Response(request.method === 'HEAD' ? null : response.body, { status: response.status, headers });
    }
  };
}

export default createWorker();
