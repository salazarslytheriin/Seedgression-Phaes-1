export const escapeHtml = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function layout(title, body) {
  return `<!doctype html><html lang="en"><body style="margin:0;padding:32px 16px;background:#edf3f5;color:#132b35;font-family:Arial,sans-serif"><table role="presentation" style="width:100%;max-width:600px;margin:auto;border-collapse:collapse;background:#fff"><tr><td style="padding:28px 32px;background:#081620;color:#f1fafa;font-size:20px;font-weight:bold">Seedgression</td></tr><tr><td style="padding:32px"><h1 style="margin:0 0 24px;font-size:25px;line-height:1.3">${escapeHtml(title)}</h1>${body}<p style="margin:32px 0 0;color:#55717c;font-size:13px">Seedgression · Flutter up. Grow forward.</p></td></tr></table></body></html>`;
}

export function notificationEmail(lead, reference, config) {
  const rows = [['Name', lead.name], ['Company', lead.company || 'Not provided'], ['Email', lead.email], ['Reference', reference]];
  const body = rows.map(([label, value]) => `<p style="margin:0 0 12px"><strong>${label}</strong><br>${escapeHtml(value)}</p>`).join('');
  return {
    from: config.from, to: config.recipients, reply_to: lead.email,
    subject: `New Seedgression enquiry · ${reference.slice(0, 8)}`,
    text: `New website enquiry\n\n${rows.map(([k,v]) => `${k}: ${v}`).join('\n')}\n\nMessage\n${lead.message}`,
    html: layout('A new enquiry', `${body}<hr style="border:0;border-top:1px solid #dde7eb;margin:24px 0"><p style="line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere">${escapeHtml(lead.message)}</p><p style="font-size:14px">Reply to this email to respond to the prospect.</p>`)
  };
}

export function receiptEmail(lead, reference, config) {
  // Do not reflect visitor-supplied names, messages, or URLs into automated mail to arbitrary addresses.
  const message = 'Thanks for contacting Seedgression. We’ve received an enquiry using this email address. Our team will review it and get back to you about the next step.';
  const note = 'If you did not send this enquiry, you can ignore this email. You have not been subscribed to a mailing list.';
  return {
    from: config.from, to: [lead.email], reply_to: config.replyTo,
    subject: 'Thanks for contacting Seedgression',
    text: `${message}\n\nYou can reply to this email if there is anything else you would like to share.\n\nEnquiry reference: ${reference}\n\n${note}\n\nThe Seedgression team`,
    html: layout('Thanks for reaching out.', `<p style="line-height:1.7">${message}</p><p style="line-height:1.7">You can reply to this email if there is anything else you would like to share.</p><p style="font-size:13px;color:#55717c">Enquiry reference: ${escapeHtml(reference)}</p><p style="font-size:13px;color:#55717c;line-height:1.6">${note}</p>`)
  };
}
